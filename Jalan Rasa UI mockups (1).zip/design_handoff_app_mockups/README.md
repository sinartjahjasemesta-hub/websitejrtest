# Handoff: Jalan Rasa — Ordering App Mockups

## Overview
8 iOS mockup screens for Jalan Rasa, a rest-area food & beverage brand ("Teman Rasa, di Perjalanan" — a taste companion for the road). The app lets travelers browse the menu (JR Meals, JR Bread, JR Coffee), order ahead, pay, and pick up at a rest-area location.

## About the Design Files
The bundled file (`Jalan Rasa App.dc.html`) is a **design reference built in HTML/React** — a prototype showing intended look, layout, and copy, not production code to copy verbatim. The task is to **recreate these screens natively in the target codebase's environment** (React Native, SwiftUI, Flutter, etc. — whichever the project already uses, or the best fit if greenfield), using its existing component/navigation patterns.

The file is a single "Design Component" (`.dc.html`) — it streams 8 phone mockups side by side on one canvas for review; it is not a working app (no navigation between screens, no state). Each phone frame is one independent screen.

## Fidelity
**High-fidelity.** Colors, type, spacing, and copy are final and pulled directly from the brand's Graphic Standard Manual. Recreate pixel-accurately where feasible; iOS device chrome (status bar, home indicator) in the mockup is a presentation frame only — use the OS's real chrome in the built app.

## Design Tokens

**Colors**
- Primary Orange: `#F15B2B`
- Secondary Cream White: `#FBFFF8`
- Tertiary Red: `#BD202E`
- Tertiary Cocoa: `#402D20`
- Neutral Light 1: `#E6E6E6`
- Neutral Light 2: `#F2F2F3`
- Black: `#000000` / White: `#FFFFFF`
- Muted text/icon (not in official palette, used for secondary UI text): `#7A6F63`, `#9C948C`, `#B7AEA4` (warm grays derived from cocoa)
- Card border/divider: `#ECE9E4`

**Typography**
- Display / headings: **Rooney Sans** (brand font — licensed, not on Google Fonts). Substituted in the mockup with **Baloo 2** (Google Fonts, weights 500–800) as the closest freely-available rounded-bold match. Get the real Rooney Sans license from the brand team for production.
- Body / UI text: **Satoshi** (loaded via Fontshare CDN in the mockup: `https://api.fontshare.com/v2/css?f[]=satoshi@400,500,700,900`). Satoshi has a free license from Fontshare — usable directly in production, or self-host it.

**Radii**: cards 16px, larger cards/sheets 16–26px, pills/buttons 100px (full), avatar circles 50%.
**Shadows**: soft ambient `0 2px 8px rgba(64,45,32,0.06)` on white cards.

## Assets
`/assets` contains only the images actually used by the mockup (trimmed for repo size; downscaled to ~700px max side, still crisp for the phone-frame scale they render at):
- `logo-full-white.png` — primary wordmark, white variant (for dark/color backgrounds)
- `jr-meals-icon.png`, `jr-bread-icon.png`, `jr-coffee-icon.png` — sub-brand marks (JR + product glyph)
- `prod-kampung.png`, `prod-hongkong.png`, `prod-caramel-latte.png`, `prod-roti-manis.png`, `prod-roti-asin.png` — real product photography used for menu/cart/detail imagery

These are downscaled working copies. Get final production-resolution assets, other logo color variants, and any missing SKUs (drinks, meals, bread not yet photographed) from the brand/marketing team's original Jalan Rasa brand folder.

## Screens

### 1. Onboarding / Login
Full-bleed food photo background (darkened with a cocoa gradient overlay bottom-heavy), white logo lockup + italic tagline top-anchored to bottom content, and a cream (`#FBFFF8`) bottom sheet card (26px radius) with: heading "Masuk untuk mulai pesan", a phone-number field (+62 prefix, divider, placeholder), a full-width orange pill CTA "Kirim Kode OTP", and an underlined "Lanjutkan sebagai tamu" guest link.

### 2. Beranda (Home)
- Header: location pill (pin icon + "Rest Area KM 57A" + chevron) left, circular orange avatar initial right.
- Greeting: "Halo, Dinda!" (Baloo 2 24px bold) + subhead.
- Search pill (`#F2F2F3`, 100px radius, search icon + placeholder).
- Promo banner: orange→red diagonal gradient card, "Promo Gajian!" headline, subcopy, white pill CTA.
- 3-up category row (JR Meals / JR Bread / JR Coffee) — white rounded cards with icon + label.
- "Paling Laris" horizontal scroll of product cards (image top, name/price/rating).
- "Menu JR Bread" 2-col grid of product cards.
- Bottom tab bar: Beranda (active, orange) / Menu / Riwayat / Profil, all with simple line-icon + label.

### 3. Detail Produk (Product Detail)
Full-width hero photo (320px) with glass-circle back and favorite buttons overlaid top. Below: title, category subtitle, rating, large orange price, description paragraph, "Tingkat Pedas" spice-level pill selector (Original/Sedang/Pedas, first selected filled), quantity stepper (circle −/count/+). Sticky bottom bar: total + orange "Tambah ke Keranjang" pill button.

### 4. Keranjang (Cart)
Header with back + title. Pickup-location chip (`#F2F2F3`). Stacked item rows (64px thumb, name, variant note, price, mini qty stepper). Dashed promo-code row. Price breakdown (subtotal/service fee/total). Sticky bottom orange CTA with running total.

### 5. Pembayaran (Checkout)
Header. Cocoa (`#402D20`) pickup-info card (location + ready time, white/peach text). Collapsed order summary lines. Payment-method list (QRIS selected/radio, GoPay, Kartu Debit/Kredit) as a white rounded list with dividers. Sticky bottom orange "Bayar Sekarang" CTA with total.

### 6. Status Pesanan (Order Status / Pickup Tracking)
Centered success check icon (orange circle), "Pesanan Diterima!" heading. 3-step horizontal progress tracker (Diterima done → Disiapkan active → Siap Diambil pending) connected by lines. Dashed orange pickup-code card with large code ("JR-4821"). Estimated ready time row. Placeholder location/map card. Order line-item recap. Outlined orange "Kembali ke Beranda" button.

### 7. Riwayat Pesanan (Order History)
Header + horizontal filter chip row (Semua active / Diproses / Selesai / Dibatalkan). Order cards: order ID + status pill (color varies: cocoa = in progress, neutral = selesai, red = dibatalkan), thumbnail + item summary + date, total + action button (Lacak / Pesan Lagi / Detail depending on status). Same bottom tab bar, "Riwayat" active.

### 8. Profil (Profile)
Orange header block (rounded bottom corners) with avatar initial, name, phone. Overlapping white membership card ("Member Jalan Rasa" + points balance + "Lihat Reward" outline button). "Akun" list section (Alamat Pengiriman, Metode Pembayaran, Riwayat Pesanan, Notifikasi). "Lainnya" list section (Bantuan & FAQ, Tentang Jalan Rasa). Centered red "Keluar" (log out) text action. Version footer. Bottom tab bar, "Profil" active.

## Interactions & Behavior (intended, not built in the static mockup)
- Onboarding → OTP flow → Home.
- Home: tapping a product card → Product Detail; tapping category → filtered menu list (not mocked); tapping cart icon/CTA → Cart.
- Product Detail: spice-level chips are single-select; qty stepper min 1; "Tambah ke Keranjang" adds item and could show a toast/badge update on cart icon.
- Cart → Checkout → (payment) → Order Status. Order Status ideally auto-updates the 3-step tracker via polling/push once a backend order-status API exists.
- Order History rows route to Order Status (in-progress) or a read-only order detail (completed/cancelled).
- Bottom tab bar persists across Home / Riwayat / Profil (and a not-yet-designed Menu tab); Product Detail/Cart/Checkout/Order Status are pushed stack screens without the tab bar.

## State Management (suggested)
- Auth/session state (guest vs logged-in phone number).
- Cart state: line items (product id, variant/spice level, qty, price).
- Order state machine: `received → preparing → ready` with a pickup code and ETA.
- Order history list (paginated, filterable by status).
- User profile (name, phone, points balance, saved addresses/payment methods).

## Files
- `Jalan Rasa App.dc.html` — the design file containing all 8 screens (open in a browser to view; built as a Design Component, streams via a small runtime include — the important part for a developer is the rendered layout/CSS, not the `.dc.html` mechanism itself).
- `ios-frame.jsx` — the iPhone bezel/status-bar/keyboard chrome component used purely for presentation in the mockup; not needed in the production app (use platform-native chrome).
- `assets/` — brand images referenced above.
