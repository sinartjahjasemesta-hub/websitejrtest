# Jalan Rasa — Ordering App Prototype

A working prototype of the Jalan Rasa app ("Teman Rasa, di Perjalanan") — a
rest-area food & beverage ordering experience. Built as a mobile-first React
web app from the original design handoff (`Jalan Rasa App.dc.html`, 8 iOS
mockup screens), recreated pixel-close with real navigation and interactive
state instead of a static mockup.

## Stack

- React 19 + TypeScript + Vite
- React Router (client-side navigation between screens)
- React Context for cart / auth / order state, persisted to `localStorage`

## Run it

```bash
npm install
npm run dev
```

Open the printed local URL. The layout is mobile-first: on a phone-width
viewport it fills the screen; on a wider screen it's presented centered in a
phone-frame for review purposes.

## Screens / flow

1. **Onboarding** — phone number entry ("send OTP", simulated) or continue as guest
2. **Beranda (Home)** — location pill, search, promo banner, categories, best sellers, JR Bread menu
3. **Menu** — category-filterable product grid (Semua / JR Meals / JR Bread / JR Coffee)
4. **Detail Produk** — hero photo, description, spice/temperature variant picker, qty stepper, add to cart
5. **Keranjang (Cart)** — line items with qty steppers, promo code field, price breakdown
6. **Pembayaran (Checkout)** — pickup info, order summary, payment method selection
7. **Status Pesanan** — pickup code, 3-step order progress tracker
8. **Riwayat Pesanan (Order History)** — filterable order list (Semua / Diproses / Selesai / Dibatalkan)
9. **Profil** — member points, account/settings list, logout

Cart, auth session, and order history persist across reloads via
`localStorage`. Placing an order clears the cart and adds a new entry to
order history with a freshly generated pickup code.

## Design tokens

Colors, type, and copy are pulled from the original brand handoff:

- Primary Orange `#F15B2B`, Cream `#FBFFF8`, Red `#BD202E`, Cocoa `#402D20`
- Display font: **Baloo 2** (Google Fonts) — stand-in for the licensed brand font Rooney Sans
- Body font: **Satoshi** (Fontshare)

See `src/index.css` for the full token set.

## Production notes

This is a front-end prototype: no backend, payments, or OTP delivery are
wired up (see inline comments where flows are simulated). Before shipping,
swap in real auth/OTP, payment, and order APIs, and license Rooney Sans for
production typography.
