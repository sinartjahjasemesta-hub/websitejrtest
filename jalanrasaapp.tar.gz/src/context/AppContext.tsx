import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { getProduct, type Product } from '../data/products'
import imgRotiManis from '../assets/prod-roti-manis.png'
import imgCaramelLatte from '../assets/prod-caramel-latte.png'

export interface CartItem {
  cartItemId: string
  productId: string
  name: string
  image: string
  price: number
  qty: number
  variant: string | null
}

export type OrderStatus = 'disiapkan' | 'siap' | 'selesai' | 'dibatalkan'

export interface OrderItem {
  name: string
  qty: number
  lineTotal: number
}

export interface Order {
  id: string
  items: OrderItem[]
  itemsSummary: string
  subtotal: number
  serviceFee: number
  total: number
  status: OrderStatus
  createdAtLabel: string
  createdAt: number
  pickupCode: string
  pickupLocation: string
  etaLabel: string
  paymentMethod: string
  image?: string
}

interface AppState {
  guestOrUser: { isGuest: boolean; name: string; phone: string } | null
  login: (phone: string) => void
  continueAsGuest: () => void
  logout: () => void

  pickupLocation: string

  cart: CartItem[]
  addToCart: (product: Product, qty: number, variant: string | null) => void
  updateCartQty: (cartItemId: string, qty: number) => void
  removeFromCart: (cartItemId: string) => void
  clearCart: () => void
  cartSubtotal: number
  serviceFee: number
  cartTotal: number

  orders: Order[]
  placeOrder: (paymentMethod: string) => Order
  latestOrder: Order | null
}

const AppContext = createContext<AppState | null>(null)

const SERVICE_FEE = 3000
const STORAGE_KEY = 'jalanrasa_state_v1'

function uid() {
  return Math.random().toString(36).slice(2, 9)
}

function seedOrders(): Order[] {
  return [
    {
      id: 'JR20260722-089',
      items: [{ name: 'Roti Manis Keju', qty: 2, lineTotal: 16000 }],
      itemsSummary: 'Roti Manis Keju +1 lainnya',
      subtotal: 26000,
      serviceFee: 0,
      total: 26000,
      status: 'selesai',
      createdAtLabel: '22 Jul 2026 · 09:05',
      createdAt: new Date('2026-07-22T09:05:00').getTime(),
      pickupCode: 'JR-0892',
      pickupLocation: 'Rest Area KM 57A, Tol Jagorawi',
      etaLabel: 'Selesai',
      paymentMethod: 'QRIS',
      image: imgRotiManis,
    },
    {
      id: 'JR20260715-041',
      items: [{ name: 'Caramel Latte', qty: 1, lineTotal: 18000 }],
      itemsSummary: 'Caramel Latte',
      subtotal: 18000,
      serviceFee: 0,
      total: 18000,
      status: 'dibatalkan',
      createdAtLabel: '15 Jul 2026 · 16:40',
      createdAt: new Date('2026-07-15T16:40:00').getTime(),
      pickupCode: 'JR-0415',
      pickupLocation: 'Rest Area KM 57A, Tol Jagorawi',
      etaLabel: 'Dibatalkan',
      paymentMethod: 'GoPay',
      image: imgCaramelLatte,
    },
  ]
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [guestOrUser, setGuestOrUser] = useState<AppState['guestOrUser']>(null)
  const [cart, setCart] = useState<CartItem[]>([])
  const [orders, setOrders] = useState<Order[]>(seedOrders())
  const [pickupLocation] = useState('Rest Area KM 57A')

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw)
        if (parsed.guestOrUser) setGuestOrUser(parsed.guestOrUser)
        if (parsed.cart) setCart(parsed.cart)
        if (parsed.orders) setOrders(parsed.orders)
      }
    } catch {
      // ignore corrupt storage
    }
  }, [])

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ guestOrUser, cart, orders }))
  }, [guestOrUser, cart, orders])

  const login = (phone: string) => setGuestOrUser({ isGuest: false, name: 'Dinda Prameswari', phone })
  const continueAsGuest = () => setGuestOrUser({ isGuest: true, name: 'Tamu', phone: '' })
  const logout = () => setGuestOrUser(null)

  const addToCart: AppState['addToCart'] = (product, qty, variant) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.productId === product.id && i.variant === variant)
      if (existing) {
        return prev.map((i) =>
          i.cartItemId === existing.cartItemId ? { ...i, qty: i.qty + qty } : i,
        )
      }
      return [
        ...prev,
        {
          cartItemId: uid(),
          productId: product.id,
          name: product.name,
          image: product.image,
          price: product.price,
          qty,
          variant,
        },
      ]
    })
  }

  const updateCartQty: AppState['updateCartQty'] = (cartItemId, qty) => {
    setCart((prev) =>
      qty <= 0
        ? prev.filter((i) => i.cartItemId !== cartItemId)
        : prev.map((i) => (i.cartItemId === cartItemId ? { ...i, qty } : i)),
    )
  }

  const removeFromCart: AppState['removeFromCart'] = (cartItemId) => {
    setCart((prev) => prev.filter((i) => i.cartItemId !== cartItemId))
  }

  const clearCart = () => setCart([])

  const cartSubtotal = useMemo(() => cart.reduce((sum, i) => sum + i.price * i.qty, 0), [cart])
  const serviceFee = cart.length > 0 ? SERVICE_FEE : 0
  const cartTotal = cartSubtotal + serviceFee

  const placeOrder: AppState['placeOrder'] = (paymentMethod) => {
    const now = new Date()
    const dateLabel = now.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })
    const timeLabel = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    const code = `JR-${Math.floor(1000 + Math.random() * 9000)}`
    const items: OrderItem[] = cart.map((i) => ({
      name: i.name,
      qty: i.qty,
      lineTotal: i.price * i.qty,
    }))
    const extra = items.length > 1 ? ` +${items.length - 1} lainnya` : ''
    const eta = new Date(now.getTime() + 15 * 60000)
    const etaLabel = `Perkiraan siap: ${eta.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB (±15 menit)`

    const order: Order = {
      id: `JR${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}-${Math.floor(100 + Math.random() * 900)}`,
      items,
      itemsSummary: `${items[0]?.name ?? ''}${extra}`,
      subtotal: cartSubtotal,
      serviceFee,
      total: cartTotal,
      status: 'disiapkan',
      createdAtLabel: `${dateLabel} · ${timeLabel}`,
      createdAt: now.getTime(),
      pickupCode: code,
      pickupLocation: `${pickupLocation}, Tol Jagorawi`,
      etaLabel,
      paymentMethod,
    }
    setOrders((prev) => [order, ...prev])
    clearCart()
    return order
  }

  const latestOrder = orders[0] ?? null

  const value: AppState = {
    guestOrUser,
    login,
    continueAsGuest,
    logout,
    pickupLocation,
    cart,
    addToCart,
    updateCartQty,
    removeFromCart,
    clearCart,
    cartSubtotal,
    serviceFee,
    cartTotal,
    orders,
    placeOrder,
    latestOrder,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}

export function formatRupiah(amount: number) {
  return `Rp${amount.toLocaleString('id-ID')}`
}

export { getProduct }
