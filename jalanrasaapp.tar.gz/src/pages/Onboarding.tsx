import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import heroImg from '../assets/prod-kampung.png'
import logo from '../assets/logo-full-white.png'

export default function Onboarding() {
  const navigate = useNavigate()
  const { login, continueAsGuest } = useApp()
  const [phone, setPhone] = useState('')
  const [sending, setSending] = useState(false)

  const handleSendOtp = () => {
    if (sending) return
    setSending(true)
    const digits = phone.trim() || '812-3456-7890'
    // Prototype only: OTP delivery/verification is simulated.
    setTimeout(() => {
      login(digits)
      navigate('/home')
    }, 450)
  }

  const handleGuest = () => {
    continueAsGuest()
    navigate('/home')
  }

  return (
    <div className="app-shell" style={{ background: '#402D20' }}>
      <div style={{ position: 'relative', flex: 1, overflow: 'hidden' }}>
        <img
          src={heroImg}
          style={{
            position: 'absolute',
            inset: 0,
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            filter: 'brightness(0.5) saturate(1.1)',
          }}
          alt=""
        />
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background:
              'linear-gradient(to bottom, rgba(64,45,32,0.15) 0%, rgba(64,45,32,0.55) 55%, rgba(30,20,15,0.94) 100%)',
          }}
        />
        <div
          style={{
            position: 'relative',
            zIndex: 2,
            height: '100%',
            boxSizing: 'border-box',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'flex-end',
            padding: '32px 24px max(env(safe-area-inset-bottom, 24px), 32px)',
            gap: 22,
          }}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, alignItems: 'flex-start' }}>
            <img src={logo} style={{ width: 168 }} alt="Jalan Rasa" />
            <div style={{ font: "italic 600 14px 'Baloo 2',sans-serif", color: '#FBFFF8', opacity: 0.92 }}>
              Teman Rasa, di Perjalanan
            </div>
          </div>
          <div
            style={{
              background: '#FBFFF8',
              borderRadius: 26,
              padding: '22px 20px',
              display: 'flex',
              flexDirection: 'column',
              gap: 14,
              boxShadow: 'var(--shadow-sheet)',
            }}
          >
            <div style={{ font: "700 17px 'Baloo 2',sans-serif", color: '#402D20' }}>Masuk untuk mulai pesan</div>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                background: '#F2F2F3',
                borderRadius: 14,
                padding: '14px 16px',
              }}
            >
              <span style={{ font: "700 14px 'Satoshi',sans-serif", color: '#402D20' }}>+62</span>
              <div style={{ width: 1, height: 18, background: '#D8D5D0' }} />
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/[^0-9-]/g, ''))}
                placeholder="812-3456-7890"
                inputMode="numeric"
                style={{
                  border: 'none',
                  outline: 'none',
                  background: 'transparent',
                  flex: 1,
                  font: "400 14px 'Satoshi',sans-serif",
                  color: '#402D20',
                }}
              />
            </div>
            <button
              onClick={handleSendOtp}
              style={{
                background: '#F15B2B',
                border: 'none',
                borderRadius: 100,
                padding: 15,
                textAlign: 'center',
                font: "700 15px 'Satoshi',sans-serif",
                color: '#fff',
                opacity: sending ? 0.7 : 1,
              }}
            >
              {sending ? 'Mengirim…' : 'Kirim Kode OTP'}
            </button>
            <button
              onClick={handleGuest}
              style={{
                background: 'none',
                border: 'none',
                textAlign: 'center',
                font: "600 13px 'Satoshi',sans-serif",
                color: '#F15B2B',
                textDecoration: 'underline',
              }}
            >
              Lanjutkan sebagai tamu
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
