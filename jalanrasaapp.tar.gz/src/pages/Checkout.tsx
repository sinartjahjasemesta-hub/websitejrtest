import { useNavigate } from 'react-router-dom'
import { useEffect, useRef, useState } from 'react'
import AppShell from '../components/AppShell'
import ScreenHeader from '../components/ScreenHeader'
import { PinIcon } from '../components/icons'
import { formatRupiah, useApp } from '../context/AppContext'

const PAYMENT_METHODS = [
  { id: 'qris', label: 'QRIS', badge: 'QRIS', badgeBg: '#402D20', badgeColor: '#fff' },
  { id: 'gopay', label: 'GoPay', badge: 'GP', badgeBg: '#00AA5B', badgeColor: '#fff' },
  { id: 'card', label: 'Kartu Debit/Kredit', badge: 'CC', badgeBg: '#F2F2F3', badgeColor: '#402D20' },
]

export default function Checkout() {
  const navigate = useNavigate()
  const { cart, cartTotal, pickupLocation, placeOrder } = useApp()
  const [method, setMethod] = useState('qris')
  const [paying, setPaying] = useState(false)
  const orderPlaced = useRef(false)

  useEffect(() => {
    if (cart.length === 0 && !orderPlaced.current) navigate('/cart', { replace: true })
  }, [cart.length, navigate])

  if (cart.length === 0 && !orderPlaced.current) {
    return null
  }

  const handlePay = () => {
    if (paying) return
    setPaying(true)
    const methodLabel = PAYMENT_METHODS.find((m) => m.id === method)?.label ?? 'QRIS'
    setTimeout(() => {
      orderPlaced.current = true
      const order = placeOrder(methodLabel)
      navigate(`/order-status/${order.id}`, { replace: true })
    }, 500)
  }

  return (
    <AppShell>
      <ScreenHeader title="Pembayaran" />
      <div className="app-scroll" style={{ padding: '6px 20px 20px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div style={{ background: '#402D20', borderRadius: 18, padding: 16, color: '#fff', display: 'flex', flexDirection: 'column', gap: 4 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <PinIcon color="#F5A98A" size={15} />
            <span style={{ font: "400 11px 'Satoshi',sans-serif", color: '#F5A98A' }}>Diambil di</span>
          </div>
          <div style={{ font: "700 14.5px 'Satoshi',sans-serif" }}>{pickupLocation}, Tol Jagorawi</div>
          <div style={{ font: "400 12px 'Satoshi',sans-serif", color: '#D8C7BC', marginTop: 2 }}>Siap dalam ~15 menit</div>
        </div>

        <div>
          <div style={{ font: "700 14px 'Satoshi',sans-serif", color: '#402D20', marginBottom: 8 }}>Ringkasan Pesanan</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {cart.map((item) => (
              <div
                key={item.cartItemId}
                style={{ display: 'flex', justifyContent: 'space-between', font: "400 12.5px 'Satoshi',sans-serif", color: '#7A6F63' }}
              >
                <span>
                  {item.name} x{item.qty}
                </span>
                <span>{formatRupiah(item.price * item.qty)}</span>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div style={{ font: "700 14px 'Satoshi',sans-serif", color: '#402D20', marginBottom: 8 }}>Metode Pembayaran</div>
          <div style={{ display: 'flex', flexDirection: 'column', background: '#fff', borderRadius: 16, overflow: 'hidden', boxShadow: 'var(--shadow-card)' }}>
            {PAYMENT_METHODS.map((m, idx) => {
              const selected = m.id === method
              return (
                <button
                  key={m.id}
                  onClick={() => setMethod(m.id)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 12,
                    padding: 14,
                    border: 'none',
                    borderBottom: idx < PAYMENT_METHODS.length - 1 ? '1px solid #ECE9E4' : 'none',
                    background: 'none',
                    textAlign: 'left',
                  }}
                >
                  <div
                    style={{
                      width: 34,
                      height: 24,
                      borderRadius: 6,
                      background: m.badgeBg,
                      color: m.badgeColor,
                      font: "700 9px 'Satoshi',sans-serif",
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    {m.badge}
                  </div>
                  <span style={{ flex: 1, font: "600 13px 'Satoshi',sans-serif", color: '#402D20' }}>{m.label}</span>
                  <div
                    style={{
                      width: 18,
                      height: 18,
                      borderRadius: '50%',
                      background: selected ? '#F15B2B' : 'transparent',
                      boxShadow: selected ? 'inset 0 0 0 3px #fff, 0 0 0 1.5px #F15B2B' : 'none',
                      border: selected ? 'none' : '1.5px solid #D8D5D0',
                    }}
                  />
                </button>
              )
            })}
          </div>
        </div>
      </div>
      <div style={{ flex: 'none', padding: '14px 20px max(env(safe-area-inset-bottom, 14px), 20px)', background: '#fff', borderTop: '1px solid #ECE9E4' }}>
        <button
          onClick={handlePay}
          style={{
            width: '100%',
            background: '#F15B2B',
            color: '#fff',
            font: "700 14.5px 'Satoshi',sans-serif",
            padding: 16,
            borderRadius: 100,
            textAlign: 'center',
            border: 'none',
            opacity: paying ? 0.7 : 1,
          }}
        >
          {paying ? 'Memproses…' : `Bayar Sekarang · ${formatRupiah(cartTotal)}`}
        </button>
      </div>
    </AppShell>
  )
}
