import { useNavigate } from 'react-router-dom'
import AppShell from '../components/AppShell'
import BottomTabBar from '../components/BottomTabBar'
import { ChevronRightIcon } from '../components/icons'
import { useApp } from '../context/AppContext'

const ACCOUNT_ROWS = ['Alamat Pengiriman', 'Metode Pembayaran', 'Riwayat Pesanan', 'Notifikasi']
const OTHER_ROWS = ['Bantuan & FAQ', 'Tentang Jalan Rasa']

export default function Profile() {
  const navigate = useNavigate()
  const { guestOrUser, logout } = useApp()

  const isGuest = guestOrUser?.isGuest
  const name = isGuest ? 'Tamu' : (guestOrUser?.name ?? 'Dinda Prameswari')
  const phone = isGuest ? 'Belum masuk' : `0${guestOrUser?.phone ?? '812-3456-7890'}`
  const initial = isGuest ? 'T' : name[0]
  const points = 128

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  const handleRowClick = (row: string) => {
    if (row === 'Riwayat Pesanan') navigate('/history')
  }

  return (
    <AppShell>
      <div className="app-scroll">
        <div
          style={{
            background: '#F15B2B',
            padding: '20px 20px 34px',
            borderRadius: '0 0 28px 28px',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 10,
          }}
        >
          <div
            style={{
              width: 64,
              height: 64,
              borderRadius: '50%',
              background: '#fff',
              color: '#F15B2B',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              font: "800 24px 'Baloo 2',sans-serif",
            }}
          >
            {initial}
          </div>
          <div style={{ font: "700 18px 'Baloo 2',sans-serif", color: '#fff' }}>{name}</div>
          <div style={{ font: "400 12px 'Satoshi',sans-serif", color: '#FCD9CB' }}>{phone}</div>
        </div>

        <div
          style={{
            background: '#fff',
            borderRadius: 16,
            padding: '14px 16px',
            margin: '-20px 20px 0',
            boxShadow: 'var(--shadow-float)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <div>
            <div style={{ font: "700 12.5px 'Satoshi',sans-serif", color: '#402D20' }}>Member Jalan Rasa</div>
            <div style={{ font: "800 18px 'Baloo 2',sans-serif", color: '#F15B2B' }}>{points} poin</div>
          </div>
          <button
            style={{
              border: '1.3px solid #F15B2B',
              color: '#F15B2B',
              font: "700 11px 'Satoshi',sans-serif",
              padding: '8px 14px',
              borderRadius: 100,
              background: 'none',
            }}
          >
            Lihat Reward
          </button>
        </div>

        <div style={{ padding: '28px 20px 4px' }}>
          <div style={{ font: "700 11px 'Satoshi',sans-serif", color: '#9C948C', textTransform: 'uppercase', letterSpacing: 0.4, padding: '0 4px 8px' }}>
            Akun
          </div>
          <div style={{ background: '#fff', borderRadius: 16, overflow: 'hidden', boxShadow: 'var(--shadow-card)' }}>
            {ACCOUNT_ROWS.map((row, idx) => (
              <button
                key={row}
                onClick={() => handleRowClick(row)}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 12,
                  padding: '13px 14px',
                  borderBottom: idx < ACCOUNT_ROWS.length - 1 ? '1px solid #ECE9E4' : 'none',
                  border: 'none',
                  background: 'none',
                  textAlign: 'left',
                }}
              >
                <span style={{ flex: 1, font: "500 13.5px 'Satoshi',sans-serif", color: '#402D20' }}>{row}</span>
                <ChevronRightIcon />
              </button>
            ))}
          </div>
        </div>

        <div style={{ padding: '20px 20px 4px' }}>
          <div style={{ font: "700 11px 'Satoshi',sans-serif", color: '#9C948C', textTransform: 'uppercase', letterSpacing: 0.4, padding: '0 4px 8px' }}>
            Lainnya
          </div>
          <div style={{ background: '#fff', borderRadius: 16, overflow: 'hidden', boxShadow: 'var(--shadow-card)' }}>
            {OTHER_ROWS.map((row, idx) => (
              <button
                key={row}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 12,
                  padding: '13px 14px',
                  borderBottom: idx < OTHER_ROWS.length - 1 ? '1px solid #ECE9E4' : 'none',
                  border: 'none',
                  background: 'none',
                  textAlign: 'left',
                }}
              >
                <span style={{ flex: 1, font: "500 13.5px 'Satoshi',sans-serif", color: '#402D20' }}>{row}</span>
                <ChevronRightIcon />
              </button>
            ))}
          </div>
        </div>

        <div style={{ padding: '22px 20px 8px', textAlign: 'center' }}>
          <button onClick={handleLogout} style={{ background: 'none', border: 'none', font: "700 13.5px 'Satoshi',sans-serif", color: '#BD202E' }}>
            Keluar
          </button>
        </div>
        <div style={{ textAlign: 'center', padding: '0 0 100px', font: "400 10.5px 'Satoshi',sans-serif", color: '#C9C2BA' }}>
          Jalan Rasa v1.0.0
        </div>
      </div>
      <BottomTabBar />
    </AppShell>
  )
}
