import { useNavigate } from 'react-router-dom'
import { useState } from 'react'
import AppShell from '../components/AppShell'
import ScreenHeader from '../components/ScreenHeader'
import { PinIcon } from '../components/icons'
import { formatRupiah, useApp } from '../context/AppContext'
import QtyStepper from '../components/QtyStepper'

export default function Cart() {
  const navigate = useNavigate()
  const { cart, updateCartQty, pickupLocation, cartSubtotal, serviceFee, cartTotal } = useApp()
  const [promo, setPromo] = useState('')
  const [promoApplied, setPromoApplied] = useState(false)

  const applyPromo = () => {
    if (!promo.trim()) return
    setPromoApplied(true)
  }

  if (cart.length === 0) {
    return (
      <AppShell>
        <ScreenHeader title="Keranjang Saya" />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, padding: 20 }}>
          <span style={{ font: "700 16px 'Baloo 2',sans-serif", color: '#402D20' }}>Keranjang kamu masih kosong</span>
          <span style={{ font: "400 13px 'Satoshi',sans-serif", color: '#7A6F63', textAlign: 'center' }}>
            Yuk pilih menu favoritmu dulu
          </span>
          <button
            onClick={() => navigate('/home')}
            style={{
              marginTop: 8,
              background: '#F15B2B',
              color: '#fff',
              font: "700 13px 'Satoshi',sans-serif",
              padding: '13px 26px',
              borderRadius: 100,
              border: 'none',
            }}
          >
            Lihat Menu
          </button>
        </div>
      </AppShell>
    )
  }

  return (
    <AppShell>
      <ScreenHeader title="Keranjang Saya" />
      <div className="app-scroll" style={{ padding: '6px 20px 20px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div
          style={{
            background: '#F2F2F3',
            borderRadius: 16,
            padding: '13px 14px',
            display: 'flex',
            alignItems: 'center',
            gap: 10,
          }}
        >
          <PinIcon />
          <div style={{ flex: 1 }}>
            <div style={{ font: "700 12.5px 'Satoshi',sans-serif", color: '#402D20' }}>Ambil di {pickupLocation}</div>
          </div>
          <span style={{ font: "700 12px 'Satoshi',sans-serif", color: '#F15B2B' }}>Ganti</span>
        </div>

        {cart.map((item) => (
          <div
            key={item.cartItemId}
            style={{ background: '#fff', borderRadius: 16, padding: 12, display: 'flex', gap: 12, boxShadow: 'var(--shadow-card)' }}
          >
            <img
              src={item.image}
              style={{ width: 64, height: 64, borderRadius: 12, objectFit: 'cover', flex: 'none' }}
              alt={item.name}
            />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ font: "700 13px 'Satoshi',sans-serif", color: '#402D20' }}>{item.name}</div>
              <div style={{ font: "400 11px 'Satoshi',sans-serif", color: '#9C948C', marginTop: 2 }}>
                {item.variant ?? '1 pcs'}
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 }}>
                <span style={{ font: "700 13.5px 'Baloo 2',sans-serif", color: '#F15B2B' }}>{formatRupiah(item.price)}</span>
                <QtyStepper qty={item.qty} onChange={(v) => updateCartQty(item.cartItemId, v)} size="sm" />
              </div>
            </div>
          </div>
        ))}

        <div
          style={{
            border: '1.5px dashed #D8D5D0',
            borderRadius: 14,
            padding: '13px 14px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: 10,
          }}
        >
          {promoApplied ? (
            <>
              <span style={{ font: "600 12.5px 'Satoshi',sans-serif", color: '#402D20' }}>Kode "{promo.toUpperCase()}" dipakai</span>
              <button
                onClick={() => {
                  setPromoApplied(false)
                  setPromo('')
                }}
                style={{ background: 'none', border: 'none', font: "700 12.5px 'Satoshi',sans-serif", color: '#BD202E' }}
              >
                Batal
              </button>
            </>
          ) : (
            <>
              <input
                value={promo}
                onChange={(e) => setPromo(e.target.value)}
                placeholder="Punya kode promo?"
                style={{
                  border: 'none',
                  outline: 'none',
                  background: 'transparent',
                  flex: 1,
                  font: "500 12.5px 'Satoshi',sans-serif",
                  color: '#402D20',
                }}
              />
              <button onClick={applyPromo} style={{ background: 'none', border: 'none', font: "700 12.5px 'Satoshi',sans-serif", color: '#F15B2B' }}>
                Pakai
              </button>
            </>
          )}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: '4px 2px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', font: "400 12.5px 'Satoshi',sans-serif", color: '#7A6F63' }}>
            <span>Subtotal</span>
            <span>{formatRupiah(cartSubtotal)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', font: "400 12.5px 'Satoshi',sans-serif", color: '#7A6F63' }}>
            <span>Biaya Layanan</span>
            <span>{formatRupiah(serviceFee)}</span>
          </div>
          <div style={{ height: 1, background: '#ECE9E4', margin: '2px 0' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', font: "700 14px 'Satoshi',sans-serif", color: '#402D20' }}>
            <span>Total</span>
            <span>{formatRupiah(cartTotal)}</span>
          </div>
        </div>
      </div>
      <div style={{ flex: 'none', padding: '14px 20px max(env(safe-area-inset-bottom, 14px), 20px)', background: '#fff', borderTop: '1px solid #ECE9E4' }}>
        <button
          onClick={() => navigate('/checkout')}
          style={{
            width: '100%',
            background: '#F15B2B',
            color: '#fff',
            font: "700 14.5px 'Satoshi',sans-serif",
            padding: 16,
            borderRadius: 100,
            textAlign: 'center',
            border: 'none',
          }}
        >
          Lanjut ke Pembayaran · {formatRupiah(cartTotal)}
        </button>
      </div>
    </AppShell>
  )
}
