import { useNavigate } from 'react-router-dom'
import { useState } from 'react'
import AppShell from '../components/AppShell'
import BottomTabBar from '../components/BottomTabBar'
import { formatRupiah, useApp, type Order, type OrderStatus } from '../context/AppContext'
import imgKampung from '../assets/prod-kampung.png'

const FILTERS: { id: OrderStatus | 'all'; label: string }[] = [
  { id: 'all', label: 'Semua' },
  { id: 'disiapkan', label: 'Diproses' },
  { id: 'selesai', label: 'Selesai' },
  { id: 'dibatalkan', label: 'Dibatalkan' },
]

function statusBadge(status: OrderStatus) {
  switch (status) {
    case 'selesai':
      return { label: 'Selesai', bg: '#F2F2F3', color: '#7A6F63' }
    case 'dibatalkan':
      return { label: 'Dibatalkan', bg: '#BD202E', color: '#fff' }
    default:
      return { label: 'Sedang Disiapkan', bg: '#402D20', color: '#fff' }
  }
}

function actionFor(status: OrderStatus) {
  if (status === 'selesai') return { label: 'Pesan Lagi', style: 'filled' as const }
  if (status === 'dibatalkan') return { label: 'Detail', style: 'muted' as const }
  return { label: 'Lacak', style: 'outline' as const }
}

export default function OrderHistory() {
  const navigate = useNavigate()
  const { orders } = useApp()
  const [filter, setFilter] = useState<OrderStatus | 'all'>('all')

  const filtered = filter === 'all' ? orders : orders.filter((o) => normalize(o.status) === filter)

  function normalize(status: OrderStatus) {
    if (status === 'siap') return 'disiapkan'
    return status
  }

  const handleAction = (order: Order) => {
    if (order.status === 'disiapkan' || order.status === 'siap') {
      navigate(`/order-status/${order.id}`)
    } else if (order.status === 'selesai') {
      navigate('/menu')
    } else {
      navigate(`/order-status/${order.id}`)
    }
  }

  return (
    <AppShell>
      <div style={{ flex: 'none', padding: '20px 20px 10px' }}>
        <span style={{ font: "700 22px 'Baloo 2',sans-serif", color: '#402D20' }}>Riwayat Pesanan</span>
      </div>
      <div style={{ flex: 'none', display: 'flex', gap: 8, padding: '4px 20px 12px', overflowX: 'auto' }}>
        {FILTERS.map((f) => {
          const isActive = f.id === filter
          return (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              style={{
                flex: 'none',
                background: isActive ? '#F15B2B' : 'transparent',
                color: isActive ? '#fff' : '#7A6F63',
                border: isActive ? 'none' : '1px solid #D8D5D0',
                font: `${isActive ? 700 : 600} 11.5px 'Satoshi',sans-serif`,
                padding: '7px 16px',
                borderRadius: 100,
              }}
            >
              {f.label}
            </button>
          )
        })}
      </div>
      <div className="app-scroll" style={{ padding: '6px 20px 110px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {filtered.length === 0 && (
          <div style={{ font: "400 13px 'Satoshi',sans-serif", color: '#9C948C', textAlign: 'center', padding: '40px 0' }}>
            Belum ada pesanan di kategori ini.
          </div>
        )}
        {filtered.map((order) => {
          const badge = statusBadge(order.status)
          const action = actionFor(order.status)
          const dimmed = order.status === 'dibatalkan'
          return (
            <div
              key={order.id}
              style={{
                background: '#fff',
                borderRadius: 16,
                padding: 14,
                display: 'flex',
                flexDirection: 'column',
                gap: 10,
                boxShadow: 'var(--shadow-card)',
                opacity: dimmed ? 0.7 : 1,
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ font: "500 11px 'Satoshi',sans-serif", color: '#9C948C' }}>{order.id}</span>
                <span
                  style={{
                    background: badge.bg,
                    color: badge.color,
                    font: "700 10px 'Satoshi',sans-serif",
                    padding: '4px 10px',
                    borderRadius: 100,
                  }}
                >
                  {badge.label}
                </span>
              </div>
              <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                <img
                  src={order.image ?? imgKampung}
                  style={{ width: 48, height: 48, borderRadius: 10, objectFit: 'cover', flex: 'none' }}
                  alt=""
                />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ font: "700 13px 'Satoshi',sans-serif", color: '#402D20' }}>{order.itemsSummary}</div>
                  <div style={{ font: "400 11px 'Satoshi',sans-serif", color: '#9C948C', marginTop: 2 }}>
                    {order.createdAtLabel}
                  </div>
                </div>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ font: "700 14px 'Baloo 2',sans-serif", color: '#402D20' }}>{formatRupiah(order.total)}</span>
                <button
                  onClick={() => handleAction(order)}
                  style={{
                    border: action.style === 'outline' ? '1.3px solid #F15B2B' : action.style === 'muted' ? '1.3px solid #D8D5D0' : 'none',
                    background: action.style === 'filled' ? '#F15B2B' : 'transparent',
                    color: action.style === 'filled' ? '#fff' : action.style === 'outline' ? '#F15B2B' : '#9C948C',
                    font: "700 11px 'Satoshi',sans-serif",
                    padding: '6px 14px',
                    borderRadius: 100,
                  }}
                >
                  {action.label}
                </button>
              </div>
            </div>
          )
        })}
      </div>
      <BottomTabBar />
    </AppShell>
  )
}
