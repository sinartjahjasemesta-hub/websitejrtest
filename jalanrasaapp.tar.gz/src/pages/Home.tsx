import { useNavigate } from 'react-router-dom'
import { useState } from 'react'
import AppShell from '../components/AppShell'
import BottomTabBar from '../components/BottomTabBar'
import { PinIcon, ChevronDownIcon, SearchIcon } from '../components/icons'
import { categories, bestSellers, breadMenu, products } from '../data/products'
import { ProductCardWide, ProductCardGrid } from '../components/ProductCard'
import { useApp } from '../context/AppContext'

export default function Home() {
  const navigate = useNavigate()
  const { guestOrUser, pickupLocation } = useApp()
  const [search, setSearch] = useState('')

  const initial = (guestOrUser?.isGuest ? 'T' : guestOrUser?.name?.[0]) || 'D'
  const firstName = guestOrUser?.isGuest ? 'Tamu' : (guestOrUser?.name?.split(' ')[0] ?? 'Dinda')

  const filtered = search.trim()
    ? products.filter((p) => p.name.toLowerCase().includes(search.trim().toLowerCase()))
    : null

  return (
    <AppShell>
      <div className="app-scroll">
        <div style={{ padding: '20px 20px 4px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <PinIcon />
            <span style={{ font: "700 14px 'Baloo 2',sans-serif", color: '#402D20' }}>{pickupLocation}</span>
            <ChevronDownIcon />
          </div>
          <button
            onClick={() => navigate('/profile')}
            style={{
              width: 36,
              height: 36,
              borderRadius: '50%',
              background: '#F15B2B',
              color: '#fff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              font: "700 14px 'Baloo 2',sans-serif",
              border: 'none',
            }}
          >
            {initial}
          </button>
        </div>

        <div style={{ padding: '18px 20px 4px' }}>
          <div style={{ font: "700 24px 'Baloo 2',sans-serif", color: '#402D20' }}>Halo, {firstName}!</div>
          <div style={{ font: "400 14px 'Satoshi',sans-serif", color: '#7A6F63', marginTop: 2 }}>
            Enaknya ngemil apa hari ini?
          </div>
        </div>

        <div style={{ padding: '16px 20px 6px' }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              background: '#F2F2F3',
              borderRadius: 100,
              height: 46,
              padding: '0 16px',
            }}
          >
            <SearchIcon />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari nasi goreng, roti, kopi..."
              style={{
                border: 'none',
                outline: 'none',
                background: 'transparent',
                flex: 1,
                font: "400 13px 'Satoshi',sans-serif",
                color: '#402D20',
              }}
            />
          </div>
        </div>

        {filtered ? (
          <div style={{ padding: '16px 20px 110px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {filtered.length === 0 ? (
              <div style={{ gridColumn: '1 / -1', font: "400 13px 'Satoshi',sans-serif", color: '#9C948C', textAlign: 'center', padding: '24px 0' }}>
                Tidak ada menu yang cocok dengan "{search}"
              </div>
            ) : (
              filtered.map((p) => <ProductCardGrid key={p.id} product={p} />)
            )}
          </div>
        ) : (
          <>
            <div style={{ padding: '14px 20px 6px' }}>
              <div
                style={{
                  borderRadius: 20,
                  background: 'linear-gradient(135deg,#F15B2B,#BD202E)',
                  padding: 20,
                  position: 'relative',
                  overflow: 'hidden',
                }}
              >
                <div style={{ font: "800 24px 'Baloo 2',sans-serif", color: '#fff' }}>Promo Gajian!</div>
                <div style={{ font: "400 12.5px 'Satoshi',sans-serif", color: '#FBEAE4', margin: '4px 0 12px' }}>
                  Diskon 20% semua menu JR Coffee
                </div>
                <div
                  style={{
                    display: 'inline-block',
                    background: '#fff',
                    color: '#BD202E',
                    font: "700 12px 'Satoshi',sans-serif",
                    padding: '8px 18px',
                    borderRadius: 100,
                  }}
                >
                  Klaim Sekarang
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: 12, padding: '18px 20px 6px' }}>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => navigate(`/menu?category=${cat.id}`)}
                  style={{
                    flex: 1,
                    background: '#fff',
                    borderRadius: 16,
                    padding: '14px 8px',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: 8,
                    boxShadow: 'var(--shadow-card)',
                    border: 'none',
                  }}
                >
                  <img src={cat.icon} style={{ width: 34, height: 34, objectFit: 'contain' }} alt="" />
                  <span style={{ font: "700 11.5px 'Baloo 2',sans-serif", color: '#402D20' }}>{cat.label}</span>
                </button>
              ))}
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '18px 20px 0' }}>
              <span style={{ font: "700 17px 'Baloo 2',sans-serif", color: '#402D20' }}>Paling Laris</span>
              <button
                onClick={() => navigate('/menu')}
                style={{ background: 'none', border: 'none', font: "600 12px 'Satoshi',sans-serif", color: '#F15B2B' }}
              >
                Lihat semua
              </button>
            </div>
            <div style={{ display: 'flex', gap: 14, padding: '12px 20px', overflowX: 'auto' }}>
              {bestSellers.map((p) => (
                <ProductCardWide key={p.id} product={p} />
              ))}
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '16px 20px 0' }}>
              <span style={{ font: "700 17px 'Baloo 2',sans-serif", color: '#402D20' }}>Menu JR Bread</span>
              <button
                onClick={() => navigate('/menu?category=bread')}
                style={{ background: 'none', border: 'none', font: "600 12px 'Satoshi',sans-serif", color: '#F15B2B' }}
              >
                Lihat semua
              </button>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, padding: '12px 20px 110px' }}>
              {breadMenu.map((p) => (
                <ProductCardGrid key={p.id} product={p} />
              ))}
            </div>
          </>
        )}
      </div>
      <BottomTabBar />
    </AppShell>
  )
}
