import { useSearchParams } from 'react-router-dom'
import AppShell from '../components/AppShell'
import BottomTabBar from '../components/BottomTabBar'
import { categories, products, type Category } from '../data/products'
import { ProductCardGrid } from '../components/ProductCard'

const FILTERS: { id: Category | 'all'; label: string }[] = [
  { id: 'all', label: 'Semua' },
  ...categories.map((c) => ({ id: c.id, label: c.label })),
]

export default function Menu() {
  const [params, setParams] = useSearchParams()
  const active = (params.get('category') as Category | null) ?? 'all'

  const filtered = active === 'all' ? products : products.filter((p) => p.category === active)

  return (
    <AppShell>
      <div style={{ flex: 'none', padding: '20px 20px 10px' }}>
        <span style={{ font: "700 22px 'Baloo 2',sans-serif", color: '#402D20' }}>Menu</span>
      </div>
      <div style={{ flex: 'none', display: 'flex', gap: 8, padding: '4px 20px 12px', overflowX: 'auto' }}>
        {FILTERS.map((f) => {
          const isActive = f.id === active
          return (
            <button
              key={f.id}
              onClick={() => setParams(f.id === 'all' ? {} : { category: f.id })}
              style={{
                flex: 'none',
                background: isActive ? '#F15B2B' : 'transparent',
                color: isActive ? '#fff' : '#7A6F63',
                border: isActive ? 'none' : '1px solid #D8D5D0',
                font: `${isActive ? 700 : 600} 11.5px 'Satoshi',sans-serif`,
                padding: '7px 16px',
                borderRadius: 100,
              }}
            >
              {f.label}
            </button>
          )
        })}
      </div>
      <div className="app-scroll" style={{ padding: '6px 20px 110px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {filtered.map((p) => (
            <ProductCardGrid key={p.id} product={p} />
          ))}
        </div>
        {filtered.length === 0 && (
          <div style={{ font: "400 13px 'Satoshi',sans-serif", color: '#9C948C', textAlign: 'center', padding: '40px 0' }}>
            Belum ada menu di kategori ini.
          </div>
        )}
      </div>
      <BottomTabBar />
    </AppShell>
  )
}
