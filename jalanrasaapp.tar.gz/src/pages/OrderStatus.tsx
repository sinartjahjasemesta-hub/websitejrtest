import { Fragment, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import AppShell from '../components/AppShell'
import { CheckIcon, HistoryIcon, PinIcon } from '../components/icons'
import { formatRupiah, useApp } from '../context/AppContext'

const STEPS = [
  { key: 'diterima', label: 'Diterima' },
  { key: 'disiapkan', label: 'Disiapkan' },
  { key: 'siap', label: 'Siap Diambil' },
]

export default function OrderStatus() {
  const { orderId } = useParams()
  const navigate = useNavigate()
  const { orders } = useApp()
  const order = orders.find((o) => o.id === orderId) ?? orders[0]

  useEffect(() => {
    if (!order) navigate('/home', { replace: true })
  }, [order, navigate])

  if (!order) {
    return null
  }

  const stepIndex = order.status === 'siap' || order.status === 'selesai' ? 2 : 1

  return (
    <AppShell>
      <div className="app-scroll" style={{ padding: '20px 20px 24px', display: 'flex', flexDirection: 'column', gap: 20 }}>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, textAlign: 'center' }}>
          <div style={{ width: 64, height: 64, borderRadius: '50%', background: '#F15B2B', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <CheckIcon />
          </div>
          <div style={{ font: "700 20px 'Baloo 2',sans-serif", color: '#402D20' }}>Pesanan Diterima!</div>
          <div style={{ font: "400 13px 'Satoshi',sans-serif", color: '#7A6F63' }}>Pesanan kamu sedang disiapkan tim dapur</div>
        </div>

        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', padding: '0 8px' }}>
          {STEPS.map((step, i) => {
            const done = i < stepIndex
            const active = i === stepIndex
            const pending = i > stepIndex
            return (
              <Fragment key={step.key}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, flex: 1 }}>
                  <div
                    style={{
                      width: 26,
                      height: 26,
                      borderRadius: '50%',
                      background: done ? '#F15B2B' : '#fff',
                      border: active ? '2.5px solid #F15B2B' : pending ? '2px solid #D8D5D0' : 'none',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    {done && <CheckIcon size={12} />}
                  </div>
                  <span
                    style={{
                      font: `700 10px 'Satoshi',sans-serif`,
                      color: done || active ? (done ? '#402D20' : '#F15B2B') : '#B7AEA4',
                    }}
                  >
                    {step.label}
                  </span>
                </div>
                {i < STEPS.length - 1 && (
                  <div
                    style={{ flex: 1, height: 2, background: i < stepIndex ? '#F15B2B' : '#E6E6E6', marginTop: 13 }}
                  />
                )}
              </Fragment>
            )
          })}
        </div>

        <div style={{ border: '1.5px dashed #F15B2B', background: '#FFF4EF', borderRadius: 18, padding: 20, textAlign: 'center' }}>
          <div style={{ font: "600 12px 'Satoshi',sans-serif", color: '#9C6A54' }}>Kode Pengambilan</div>
          <div style={{ font: "800 32px 'Baloo 2',sans-serif", color: '#F15B2B', letterSpacing: 2, marginTop: 2 }}>
            {order.pickupCode}
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <HistoryIcon color="#7A6F63" size={16} />
          <span style={{ font: "500 13px 'Satoshi',sans-serif", color: '#402D20' }}>{order.etaLabel}</span>
        </div>

        <div style={{ background: '#F2F2F3', borderRadius: 16, height: 110, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
          <PinIcon color="#9C948C" size={20} />
          <span style={{ font: "600 11px 'Satoshi',sans-serif", color: '#9C948C' }}>{order.pickupLocation}</span>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {order.items.map((item) => (
            <div key={item.name} style={{ display: 'flex', justifyContent: 'space-between', font: "400 12.5px 'Satoshi',sans-serif", color: '#7A6F63' }}>
              <span>
                {item.name} x{item.qty}
              </span>
              <span>{formatRupiah(item.lineTotal)}</span>
            </div>
          ))}
        </div>

        <button
          onClick={() => navigate('/home')}
          style={{
            border: '1.5px solid #F15B2B',
            color: '#F15B2B',
            font: "700 14px 'Satoshi',sans-serif",
            padding: 15,
            borderRadius: 100,
            textAlign: 'center',
            background: 'none',
          }}
        >
          Kembali ke Beranda
        </button>
      </div>
    </AppShell>
  )
}
