import { useNavigate, useParams } from 'react-router-dom'
import { useMemo, useState } from 'react'
import AppShell from '../components/AppShell'
import { BackIcon, HeartIcon } from '../components/icons'
import { getProduct } from '../data/products'
import { formatRupiah, useApp } from '../context/AppContext'
import QtyStepper from '../components/QtyStepper'

export default function ProductDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { addToCart } = useApp()
  const product = useMemo(() => (id ? getProduct(id) : undefined), [id])

  const [variant, setVariant] = useState<string | null>(product?.variantOptions?.[0] ?? null)
  const [qty, setQty] = useState(1)
  const [favorite, setFavorite] = useState(false)
  const [justAdded, setJustAdded] = useState(false)

  if (!product) {
    return (
      <AppShell>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <span style={{ font: "500 14px 'Satoshi',sans-serif", color: '#7A6F63' }}>Produk tidak ditemukan.</span>
        </div>
      </AppShell>
    )
  }

  const total = product.price * qty

  const handleAdd = () => {
    addToCart(product, qty, variant)
    setJustAdded(true)
    setTimeout(() => navigate('/cart'), 400)
  }

  return (
    <AppShell>
      <div className="app-scroll">
        <div style={{ position: 'relative' }}>
          <img src={product.image} style={{ width: '100%', height: 320, objectFit: 'cover', display: 'block' }} alt={product.name} />
          <button
            onClick={() => navigate(-1)}
            aria-label="Kembali"
            style={{
              position: 'absolute',
              top: 20,
              left: 16,
              width: 36,
              height: 36,
              borderRadius: '50%',
              background: 'rgba(255,255,255,0.85)',
              border: 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <BackIcon size={14} />
          </button>
          <button
            onClick={() => setFavorite((f) => !f)}
            aria-label="Favorit"
            style={{
              position: 'absolute',
              top: 20,
              right: 16,
              width: 36,
              height: 36,
              borderRadius: '50%',
              background: 'rgba(255,255,255,0.85)',
              border: 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <HeartIcon filled={favorite} />
          </button>
        </div>

        <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div>
            <div style={{ font: "700 22px 'Baloo 2',sans-serif", color: '#402D20' }}>{product.name}</div>
            <div style={{ font: "400 12.5px 'Satoshi',sans-serif", color: '#9C948C', marginTop: 3 }}>{product.categoryLabel}</div>
          </div>
          <div style={{ font: "600 13px 'Satoshi',sans-serif", color: '#7A6F63' }}>
            {product.rating} ★ &nbsp;({product.reviews} ulasan)
          </div>
          <div style={{ font: "800 24px 'Baloo 2',sans-serif", color: '#F15B2B' }}>{formatRupiah(product.price)}</div>
          <div style={{ height: 1, background: '#ECE9E4', margin: '4px 0' }} />
          <div style={{ font: "700 14px 'Satoshi',sans-serif", color: '#402D20' }}>Deskripsi</div>
          <div style={{ font: "400 13px 'Satoshi',sans-serif", color: '#7A6F63', lineHeight: 1.6 }}>{product.description}</div>

          {product.variantType && product.variantOptions && (
            <>
              <div style={{ font: "700 14px 'Satoshi',sans-serif", color: '#402D20', marginTop: 6 }}>
                {product.variantType === 'spice' ? 'Tingkat Pedas' : 'Suhu'}
              </div>
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                {product.variantOptions.map((opt) => {
                  const selected = opt === variant
                  return (
                    <button
                      key={opt}
                      onClick={() => setVariant(opt)}
                      style={{
                        background: selected ? '#F15B2B' : 'transparent',
                        color: selected ? '#fff' : '#7A6F63',
                        border: selected ? 'none' : '1px solid #D8D5D0',
                        font: `${selected ? 700 : 600} 12.5px 'Satoshi',sans-serif`,
                        padding: '9px 18px',
                        borderRadius: 100,
                      }}
                    >
                      {opt}
                    </button>
                  )
                })}
              </div>
            </>
          )}

          <div style={{ font: "700 14px 'Satoshi',sans-serif", color: '#402D20', marginTop: 6 }}>Jumlah</div>
          <QtyStepper qty={qty} onChange={(v) => setQty(Math.max(1, v))} />
        </div>
      </div>
      <div
        style={{
          flex: 'none',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          background: '#fff',
          borderTop: '1px solid #ECE9E4',
          padding: '14px 20px max(env(safe-area-inset-bottom, 14px), 20px)',
        }}
      >
        <div>
          <div style={{ font: "400 11px 'Satoshi',sans-serif", color: '#9C948C' }}>Total</div>
          <div style={{ font: "700 18px 'Baloo 2',sans-serif", color: '#402D20' }}>{formatRupiah(total)}</div>
        </div>
        <button
          onClick={handleAdd}
          style={{
            background: '#F15B2B',
            color: '#fff',
            font: "700 14px 'Satoshi',sans-serif",
            padding: '15px 28px',
            borderRadius: 100,
            border: 'none',
          }}
        >
          {justAdded ? 'Ditambahkan ✓' : 'Tambah ke Keranjang'}
        </button>
      </div>
    </AppShell>
  )
}
