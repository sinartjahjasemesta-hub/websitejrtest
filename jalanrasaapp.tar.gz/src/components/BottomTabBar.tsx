import { useNavigate, useLocation } from 'react-router-dom'
import { HomeIcon, MenuGridIcon, HistoryIcon, ProfileIcon } from './icons'

const TABS = [
  { path: '/home', label: 'Beranda', Icon: HomeIcon },
  { path: '/menu', label: 'Menu', Icon: MenuGridIcon },
  { path: '/history', label: 'Riwayat', Icon: HistoryIcon },
  { path: '/profile', label: 'Profil', Icon: ProfileIcon },
]

export default function BottomTabBar() {
  const navigate = useNavigate()
  const location = useLocation()

  return (
    <div
      style={{
        flex: 'none',
        display: 'flex',
        justifyContent: 'space-around',
        alignItems: 'center',
        background: '#fff',
        borderTop: '1px solid var(--border)',
        padding: '10px 0 max(env(safe-area-inset-bottom, 10px), 14px)',
      }}
    >
      {TABS.map(({ path, label, Icon }) => {
        const active = location.pathname === path
        return (
          <button
            key={path}
            onClick={() => navigate(path)}
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 4,
              background: 'none',
              border: 'none',
              padding: '4px 10px',
            }}
          >
            <Icon color={active ? '#F15B2B' : '#B7AEA4'} size={20} />
            <span
              style={{
                font: `${active ? 700 : 600} 10px 'Satoshi',sans-serif`,
                color: active ? '#F15B2B' : '#B7AEA4',
              }}
            >
              {label}
            </span>
          </button>
        )
      })}
    </div>
  )
}
