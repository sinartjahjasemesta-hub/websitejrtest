import type { ReactNode } from 'react'

export default function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="app-shell">
      <div className="status-bar-spacer" />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: '#FBFFF8' }}>
        {children}
      </div>
    </div>
  )
}
