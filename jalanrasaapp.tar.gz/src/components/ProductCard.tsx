import { useNavigate } from 'react-router-dom'
import type { Product } from '../data/products'
import { formatRupiah } from '../context/AppContext'

export function ProductCardWide({ product }: { product: Product }) {
  const navigate = useNavigate()
  return (
    <button
      onClick={() => navigate(`/product/${product.id}`)}
      style={{
        flex: 'none',
        width: 150,
        background: '#fff',
        borderRadius: 16,
        overflow: 'hidden',
        boxShadow: 'var(--shadow-card)',
        border: 'none',
        padding: 0,
        textAlign: 'left',
        cursor: 'pointer',
      }}
    >
      <img src={product.image} style={{ width: '100%', height: 104, objectFit: 'cover', display: 'block' }} alt={product.name} />
      <div style={{ padding: '9px 10px' }}>
        <div style={{ font: "700 12.5px 'Satoshi',sans-serif", color: '#402D20' }}>{product.name}</div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 6 }}>
          <span style={{ font: "700 13px 'Baloo 2',sans-serif", color: '#F15B2B' }}>{formatRupiah(product.price)}</span>
          <span style={{ font: "600 10.5px 'Satoshi',sans-serif", color: '#9C948C' }}>{product.rating} ★</span>
        </div>
      </div>
    </button>
  )
}

export function ProductCardGrid({ product }: { product: Product }) {
  const navigate = useNavigate()
  return (
    <button
      onClick={() => navigate(`/product/${product.id}`)}
      style={{
        background: '#fff',
        borderRadius: 16,
        overflow: 'hidden',
        boxShadow: 'var(--shadow-card)',
        border: 'none',
        padding: 0,
        textAlign: 'left',
        cursor: 'pointer',
      }}
    >
      <img
        src={product.image}
        style={{ width: '100%', height: 90, objectFit: 'cover', background: '#fff', display: 'block' }}
        alt={product.name}
      />
      <div style={{ padding: '9px 10px' }}>
        <div style={{ font: "700 12.5px 'Satoshi',sans-serif", color: '#402D20' }}>{product.name}</div>
        <span style={{ font: "700 13px 'Baloo 2',sans-serif", color: '#F15B2B' }}>{formatRupiah(product.price)}</span>
      </div>
    </button>
  )
}
