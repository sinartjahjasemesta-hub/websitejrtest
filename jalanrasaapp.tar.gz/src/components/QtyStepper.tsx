interface QtyStepperProps {
  qty: number
  onChange: (qty: number) => void
  size?: 'sm' | 'lg'
}

export default function QtyStepper({ qty, onChange, size = 'lg' }: QtyStepperProps) {
  const dim = size === 'lg' ? 32 : 22
  const font = size === 'lg' ? 16 : 13
  const gap = size === 'lg' ? 16 : 10

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap }}>
      <button
        onClick={() => onChange(qty - 1)}
        style={{
          width: dim,
          height: dim,
          borderRadius: '50%',
          border: size === 'lg' ? '1.5px solid #F15B2B' : '1.3px solid #D8D5D0',
          background: 'none',
          color: size === 'lg' ? '#F15B2B' : '#7A6F63',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          font: `700 ${font}px 'Satoshi',sans-serif`,
          lineHeight: 1,
          padding: 0,
        }}
        aria-label="Kurangi jumlah"
      >
        −
      </button>
      <span style={{ font: `700 ${size === 'lg' ? 15 : 13}px 'Satoshi',sans-serif`, color: '#402D20', minWidth: 10, textAlign: 'center' }}>
        {qty}
      </span>
      <button
        onClick={() => onChange(qty + 1)}
        style={{
          width: dim,
          height: dim,
          borderRadius: '50%',
          border: 'none',
          background: '#F15B2B',
          color: '#fff',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          font: `700 ${font}px 'Satoshi',sans-serif`,
          lineHeight: 1,
          padding: 0,
        }}
        aria-label="Tambah jumlah"
      >
        +
      </button>
    </div>
  )
}
