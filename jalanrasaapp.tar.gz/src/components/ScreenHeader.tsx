import { useNavigate } from 'react-router-dom'
import { BackIcon } from './icons'

export default function ScreenHeader({ title, onBack }: { title: string; onBack?: () => void }) {
  const navigate = useNavigate()
  return (
    <div
      style={{
        flex: 'none',
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        padding: '20px 20px 12px',
      }}
    >
      <button
        onClick={onBack ?? (() => navigate(-1))}
        aria-label="Kembali"
        style={{
          background: 'none',
          border: 'none',
          padding: 6,
          margin: '-6px 0 -6px -6px',
          display: 'flex',
        }}
      >
        <BackIcon />
      </button>
      <span style={{ font: "700 19px 'Baloo 2',sans-serif", color: '#402D20' }}>{title}</span>
    </div>
  )
}
