interface IconProps {
  color?: string
  size?: number
}

export function PinIcon({ color = '#F15B2B', size = 16 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 21s7-7.2 7-12a7 7 0 10-14 0c0 4.8 7 12 7 12z" stroke={color} strokeWidth="2" />
      <circle cx="12" cy="9" r="2.4" fill={color} />
    </svg>
  )
}

export function ChevronDownIcon({ color = '#9C948C', size = 10 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 10 10">
      <path d="M2 3l3 3 3-3" stroke={color} strokeWidth="1.6" fill="none" strokeLinecap="round" />
    </svg>
  )
}

export function SearchIcon({ color = '#9C948C', size = 16 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="11" cy="11" r="7" stroke={color} strokeWidth="2" />
      <path d="M21 21l-4.3-4.3" stroke={color} strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

export function BackIcon({ color = '#402D20', size = 16 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M15 5l-8 7 8 7" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function HeartIcon({ color = '#F15B2B', size = 16, filled = false }: IconProps & { filled?: boolean }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled ? color : 'none'}>
      <path d="M12 20s-7-4.4-7-10a4.5 4.5 0 018-2.8A4.5 4.5 0 0119 10c0 5.6-7 10-7 10z" stroke={color} strokeWidth="2" />
    </svg>
  )
}

export function HomeIcon({ color = '#B7AEA4', size = 20 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M4 11.5L12 4l8 7.5" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M6 10v9h12v-9" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function MenuGridIcon({ color = '#B7AEA4', size = 20 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="4" y="4" width="7" height="7" rx="1.5" stroke={color} strokeWidth="2" />
      <rect x="13" y="4" width="7" height="7" rx="1.5" stroke={color} strokeWidth="2" />
      <rect x="4" y="13" width="7" height="7" rx="1.5" stroke={color} strokeWidth="2" />
      <rect x="13" y="13" width="7" height="7" rx="1.5" stroke={color} strokeWidth="2" />
    </svg>
  )
}

export function HistoryIcon({ color = '#B7AEA4', size = 20 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="8.5" stroke={color} strokeWidth="2" />
      <path d="M12 7.5v5l3.2 2" stroke={color} strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

export function ProfileIcon({ color = '#B7AEA4', size = 20 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="8.2" r="3.4" stroke={color} strokeWidth="2" />
      <path d="M4.5 20c1.4-3.6 4.4-5.6 7.5-5.6s6.1 2 7.5 5.6" stroke={color} strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

export function ChevronRightIcon({ color = '#C9C2BA', size = 8 }: IconProps) {
  return (
    <svg width={size} height={14} viewBox="0 0 8 14">
      <path d="M1 1l6 6-6 6" stroke={color} strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function CheckIcon({ color = '#fff', size = 30 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M5 12.5l4.5 4.5L19 7.5" stroke={color} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}
