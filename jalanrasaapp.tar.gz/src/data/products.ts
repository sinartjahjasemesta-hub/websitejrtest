import imgKampung from '../assets/prod-kampung.png'
import imgHongkong from '../assets/prod-hongkong.png'
import imgCaramelLatte from '../assets/prod-caramel-latte.png'
import imgRotiManis from '../assets/prod-roti-manis.png'
import imgRotiAsin from '../assets/prod-roti-asin.png'
import iconMeals from '../assets/jr-meals-icon.png'
import iconBread from '../assets/jr-bread-icon.png'
import iconCoffee from '../assets/jr-coffee-icon.png'

export type Category = 'meals' | 'bread' | 'coffee'

export type VariantType = 'spice' | 'temperature' | null

export interface Product {
  id: string
  name: string
  category: Category
  categoryLabel: string
  subtitle: string
  price: number
  rating: number
  reviews: number
  image: string
  description: string
  variantType: VariantType
  variantOptions?: string[]
}

export const categories: { id: Category; label: string; icon: string }[] = [
  { id: 'meals', label: 'JR Meals', icon: iconMeals },
  { id: 'bread', label: 'JR Bread', icon: iconBread },
  { id: 'coffee', label: 'JR Coffee', icon: iconCoffee },
]

export const products: Product[] = [
  {
    id: 'nasi-goreng-kampung',
    name: 'Nasi Goreng Kampung',
    category: 'meals',
    categoryLabel: 'JR Meals · Nasi & Lauk',
    subtitle: 'Nasi & Lauk',
    price: 23000,
    rating: 4.8,
    reviews: 212,
    image: imgKampung,
    description:
      'Nasi goreng kampung dengan bumbu rempah otentik, teri renyah, dan telur ceplok. Pas buat ngganjel perut selama perjalanan panjang.',
    variantType: 'spice',
    variantOptions: ['Original', 'Sedang', 'Pedas'],
  },
  {
    id: 'nasi-goreng-hongkong',
    name: 'Nasi Goreng Hongkong',
    category: 'meals',
    categoryLabel: 'JR Meals · Nasi & Lauk',
    subtitle: 'Nasi & Lauk',
    price: 25000,
    rating: 4.7,
    reviews: 158,
    image: imgHongkong,
    description:
      'Nasi goreng gaya Hongkong dengan sosis, sawi asin, dan telur orak-arik. Gurih ringan, cocok jadi teman perjalanan pagi.',
    variantType: 'spice',
    variantOptions: ['Original', 'Sedang', 'Pedas'],
  },
  {
    id: 'caramel-latte',
    name: 'Caramel Latte',
    category: 'coffee',
    categoryLabel: 'JR Coffee · Kopi Susu',
    subtitle: 'Kopi Susu',
    price: 18000,
    rating: 4.9,
    reviews: 341,
    image: imgCaramelLatte,
    description:
      'Espresso premium dipadu susu segar dan saus karamel manis gurih. Bikin melek buat lanjut perjalanan.',
    variantType: 'temperature',
    variantOptions: ['Dingin', 'Panas'],
  },
  {
    id: 'roti-manis-keju',
    name: 'Roti Manis Keju',
    category: 'bread',
    categoryLabel: 'JR Bread · Roti Manis',
    subtitle: 'Roti Manis',
    price: 8000,
    rating: 4.6,
    reviews: 97,
    image: imgRotiManis,
    description:
      'Roti empuk dengan taburan keju melimpah di atasnya. Camilan manis-gurih favorit buat di perjalanan.',
    variantType: null,
  },
  {
    id: 'roti-asin-sosis',
    name: 'Roti Asin Sosis',
    category: 'bread',
    categoryLabel: 'JR Bread · Roti Asin',
    subtitle: 'Roti Asin',
    price: 9000,
    rating: 4.5,
    reviews: 84,
    image: imgRotiAsin,
    description:
      'Roti gurih isi sosis, dipanggang hingga kecokelatan. Mengenyangkan tanpa bikin berat di perut.',
    variantType: null,
  },
]

export const getProduct = (id: string) => products.find((p) => p.id === id)
export const bestSellers = [products[0], products[2], products[1]]
export const breadMenu = products.filter((p) => p.category === 'bread')
